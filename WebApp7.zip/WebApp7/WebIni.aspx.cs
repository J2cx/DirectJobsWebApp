﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace WebApp7
{
    public partial class WebIni : System.Web.UI.Page
    {
        private static DataTable dataTableAnnonces;
        private static DateTime dateTimeIni;

        public static DataTable DataTableAnnonces
        {
            set { dataTableAnnonces = value; }
            get { return dataTableAnnonces; }
        }

        public static DateTime DateTimeIni
        {
            set { dateTimeIni = value; }
            get { return dateTimeIni; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            /*
            if (dateTimeIni == null || DateTime.Now - dateTimeIni > new TimeSpan(0, 1, 0) || dataTableAnnonces == null)
            {
                dateTimeIni = DateTime.Now;
                dataTableAnnonces = SQL.GetAllAnnonces();
            }
          */
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            if (dateTimeIni == null || DateTime.Now - dateTimeIni > new TimeSpan(0, 30, 0) || dataTableAnnonces == null)
            {
                dateTimeIni = DateTime.Now;
                dataTableAnnonces = SQL.GetAllAnnonces();
               /* foreach (DataRow drdate in dataTableAnnonces.Rows)
                {
                    drdate["datecrea"] = (DateTime)drdate["datecrea"];// DateTime(drdate["datecrea"].ToString());
                }*/
            }
        }
    }
}