﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace WebApp7.MemberPage
{
    public partial class MemberPages : System.Web.UI.MasterPage
    {
        private string userID = "";

        public string UserID
        {
            get { return userID; }
            set { userID = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
           MembershipUser myObject = Membership.GetUser();
           userID = myObject.ProviderUserKey.ToString();
          // Response.Write("MasterPage!! ClientID :"+UserID);
           Session["UserId"] = userID;
        }

        protected void ButtonAnnonces_Click(object sender, EventArgs e)
        {
            /*
            if (RechercherPage.RechercherToPage != null)
            {
                RechercherPage.RechercherToPage = false;
            }
             */
            MemberPage1.StrFliter = "";
            Response.Redirect("~/MemberPage/MemberPage1.aspx");
        }
    }
}