﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using NUnit.Extensions.Asp; 
using NUnit.Extensions.Asp.AspTester; 
using System.Text;
 


namespace WebApp7.MemberPage
{
    public partial class MemberPage1 : System.Web.UI.Page, System.Web.UI.ICallbackEventHandler
    {
        //private static DataTable dataTableAnnonces = null;
        private DataTable dataTableDisplay = new DataTable();
        private static string strFliter = "";
        //private static DateTime dateTimeIni;

        public static string StrFliter
        {
            get { return strFliter; }
            set { strFliter = value; }
        }
        /*
        public static DataTable DataTableAnnonces
        {
            set { dataTableAnnonces = value; }
            get { return dataTableAnnonces; }
        }
        */
        protected void Page_Load(object sender, EventArgs e)
        {
            ButtonEnabledCheck();
            StringBuilder context1 = new StringBuilder();
            //context1.Append("function nimabi(arg, context)");
            //context1.Append("{");
            context1.Append("alert('sb')");
            //context1.Append(" alert('da sb')");
            //context1.Append("}");



            String cbReference = Page.ClientScript.GetCallbackEventReference(this, "arg", "ReceiveServerData", "context");
            //String cbReference = Page.ClientScript.GetCallbackEventReference(this, "arg", "ReceiveServerData", "context");
            String callbackScript = "function CallTheServer(arg, context) {" + cbReference + "; }";
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "CallTheServer", callbackScript, true);


            String cbReference3 = Page.ClientScript.GetCallbackEventReference(this, "arg", "ReceiveServerData3", "context");
            //String cbReference = Page.ClientScript.GetCallbackEventReference(this, "arg", "ReceiveServerData", "context");
            String callbackScript3 = "function CallTheServer3(arg, context) {" + cbReference3 + "; }";
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "CallTheServer3", callbackScript3, true);
            /*
            if (this.IsPostBack)
            {
                string targetCtrl = Page.Request.Params.Get("__EVENTARGUMENT");
                if (targetCtrl != null && targetCtrl != "")
                {

                    OpenAnAnnonce(targetCtrl);
                }
               // Response.Write("<script language='javascript'>alert('" + targetCtrl + "')</script >");
            }
        */
            
        }

        public void OpenAnAnnonce(string strID)
        {
   
            
        }


        private string GetPostBackControl()
        {
            string Outupt = "";

            //get the __EVENTTARGET of the Control that cased a PostBack(except Buttons and ImageButtons)
            string targetCtrl = Page.Request.Params.Get("__EVENTTARGET");
            if (targetCtrl != null && targetCtrl != string.Empty)
            {
                Outupt = targetCtrl;
            }
            else
            {
                //if button is cased a postback
                foreach (string str in Request.Form)
                {
                    Control Ctrl = Page.FindControl(str);
                    if (Ctrl is Button)
                    {
                        Outupt = Ctrl.ID;
                        break;
                    }
                }
            }
            return Outupt;
        }


        protected void MultiView1_Init(object sender, EventArgs e)
        {
            /*
            if (RechercherPage.DataTableRechercher != null && RechercherPage.DataTableRechercher.Rows.Count>0 && RechercherPage.RechercherToPage)
            {
                MultiView1_Rechercher();
            }
            else
            {
                MultiView1_Original();
            }
             */
            MultiView1_Original();
        }

        private void MultiView1_Original()
        {
            if (MultiView1.Views.Count > 1)
            {
                return;
            }
            
            if (WebIni.DataTableAnnonces == null)
            {
                WebIni.DateTimeIni = DateTime.Now;
                WebIni.DataTableAnnonces = SQL.GetAllAnnonces();
                Label2.Text = Label2.Text + " ini ";
            }
            System.Text.StringBuilder output = new System.Text.StringBuilder();
            HttpCookie aCookie;

            if (Request.Cookies["userinfo"] == null)
            {
                Response.Cookies["userInfo"]["userName"] = "patrick";
                Response.Cookies["userInfo"]["lastVisit"] = DateTime.Now.ToString();
                Response.Cookies["userInfo"].Expires = DateTime.Now.AddDays(1);
            }
            for (int i = 0; i < Request.Cookies.Count; i++)
            {
                aCookie = Request.Cookies[i];
                output.Append("Cookie name = " + Server.HtmlEncode(aCookie.Name)
                    + "<br />");
                output.Append("Cookie value = " + Server.HtmlEncode(aCookie.Value)
                    + "<br /><br />");
            }
            //Label2.Text = output.ToString();
            //DataTable dataTable = null;
            /*
            if (dataTableAnnonces == null)
            {
                dataTableAnnonces = SQL.GetAllAnnonces();
                System.Text.StringBuilder output = new System.Text.StringBuilder();
                HttpCookie aCookie;

                if (Request.Cookies["userinfo"] == null)
                {
                    Response.Cookies["userInfo"]["userName"] = "patrick";
                    Response.Cookies["userInfo"]["lastVisit"] = DateTime.Now.ToString();
                    Response.Cookies["userInfo"].Expires = DateTime.Now.AddDays(1);
                }
                for (int i = 0; i < Request.Cookies.Count; i++)
                {
                    aCookie = Request.Cookies[i];
                    output.Append("Cookie name = " + Server.HtmlEncode(aCookie.Name)
                        + "<br />");
                    output.Append("Cookie value = " + Server.HtmlEncode(aCookie.Value)
                        + "<br /><br />");
                }
                Label2.Text = output.ToString();


            }
             */
            dataTableDisplay = WebIni.DataTableAnnonces.Clone();


            foreach (DataRow dr in WebIni.DataTableAnnonces.Select(strFliter))
            {
                dataTableDisplay.ImportRow(dr);
            }
            int nbAnnonces = 0;
            int nbPage = 1;
            int nbInPage = 5;
            //Table1.Width = TableHeader.Width;

            foreach (DataRow dr in dataTableDisplay.Rows)
            {
                nbAnnonces++;
                TableRow tRow = new TableRow();
                tRow.Width = TableHeaderRow1.Width;
                tRow.Attributes.Add("style", "text-aligne:left");
                tRow.Attributes.Add("class", "over");
                tRow.Attributes.Add("onmouseover", "Show1('"+dr["id"].ToString()+"');");
                tRow.Attributes.Add("onmouseout", "Hide1();");
                tRow.Attributes.Add("onclick", "ShowAnnonce('"+dr["id"].ToString()+"');");
                //tRow.Attributes.Add("onclick", "TRow_Click;");
                //tRow.Attributes.Add("tooltip","tooltip!!!!!!!!!!!!!");
 
                TableCell dateCell = new TableCell();
                dateCell.Text = ((DateTime)dr["datecrea"]).Date.ToShortDateString();
                dateCell.Width = TableHeaderCellDate.Width;
                tRow.Cells.Add(dateCell);

                TableCell posteCell = new TableCell();
                posteCell.Text = dr["poste"].ToString();
                posteCell.Width = TableHeaderCellPoste.Width;
                tRow.Cells.Add(posteCell);

                TableCell entrepriseCell = new TableCell();
                entrepriseCell.Text = dr["entreprise"].ToString();
                entrepriseCell.Width = TableHeaderCellEntreprise.Width;
                tRow.Cells.Add(entrepriseCell);

                TableCell locationCell = new TableCell();
                locationCell.Text = dr["location"].ToString();
                //locationCell.Width = TableHeaderCellLocation.Width;
                tRow.Cells.Add(locationCell);

                

                if (nbAnnonces <= nbInPage)
                {
                    Table1.Rows.Add(tRow);
                }
                else if (nbAnnonces == (nbInPage * nbPage + 1))
                {
                    nbPage++;
                    Table tableTmp = new Table();
                    tableTmp.Width = TableHeader.Width;
                    tableTmp.Rows.Add(tRow);
                    View viewTmp = new View();
                    viewTmp.Controls.Add(tableTmp);
                    MultiView1.Views.Add(viewTmp);
                }
                else
                {
                    ((MultiView1.Views[MultiView1.Views.Count - 1]).Controls[0] as Table).Rows.Add(tRow);
                }

                //MultiView1.ActiveViewIndex = 0;
            }
        }

        private void MultiView1_Rechercher()
        {
            int nbAnnonces = 0;
            int nbPage = 1;
            int nbInPage = 5;

            foreach (DataRow dr in RechercherPage.DataTableRechercher.Rows)
            {
                nbAnnonces++;
                TableRow tRow = new TableRow();
                tRow.Width = TableHeaderRow1.Width;
                tRow.Attributes.Add("style", "text-aligne:left");
                TableCell dateCell = new TableCell();
                dateCell.Text = dr[1].ToString();
                dateCell.Width = TableHeaderCellDate.Width;
                tRow.Cells.Add(dateCell);

                TableCell posteCell = new TableCell();
                posteCell.Text = dr[7].ToString();
                posteCell.Width = TableHeaderCellPoste.Width;
                tRow.Cells.Add(posteCell);

                TableCell entrepriseCell = new TableCell();
                entrepriseCell.Text = dr[13].ToString();
                entrepriseCell.Width = TableHeaderCellEntreprise.Width;
                tRow.Cells.Add(entrepriseCell);

                TableCell locationCell = new TableCell();
                locationCell.Text = dr[8].ToString();
                //locationCell.Width = TableHeaderCellLocation.Width;
                tRow.Cells.Add(locationCell);

                if (nbAnnonces <= nbInPage)
                {
                    Table1.Rows.Add(tRow);
                }
                else if (nbAnnonces == (nbInPage * nbPage + 1))
                {
                    nbPage++;
                    Table tableTmp = new Table();
                    tableTmp.Width = TableHeader.Width;
                    tableTmp.Rows.Add(tRow);
                    View viewTmp = new View();
                    viewTmp.Controls.Add(tableTmp);
                    MultiView1.Views.Add(viewTmp);
                }
                else
                {
                    ((MultiView1.Views[MultiView1.Views.Count - 1]).Controls[0] as Table).Rows.Add(tRow);
                }
            }
        }

        protected void ButtonSuivante_Click(object sender, EventArgs e)
        {
            if (MultiView1.Views.Count > MultiView1.ActiveViewIndex + 1)
            {
                MultiView1.ActiveViewIndex++;
            }
            ButtonEnabledCheck();
        }

        protected void ButtonPreview_Click(object sender, EventArgs e)
        {
            if (MultiView1.ActiveViewIndex >0)
            {
                MultiView1.ActiveViewIndex--;
            }
            ButtonEnabledCheck();

        }

        protected void ButtonEnabledCheck()
        {
            if (MultiView1.Views.Count >1 && MultiView1.Views.Count > MultiView1.ActiveViewIndex + 1)
            {
                ButtonSuivante.Enabled = true;
            }
            else
            {
                ButtonSuivante.Enabled = false;
            }
            if (MultiView1.ActiveViewIndex > 0)
            {
                ButtonPreview.Enabled = true;
            }
            else
            {
                ButtonPreview.Enabled = false;
            }
        }


        private string tooltip="";
        public void RaiseCallbackEvent(String eventArgument)
        {
            //string[] fullpath = eventArgument.Split(new string[]{":::"},StringSplitOptions.RemoveEmptyEntries);
            //if (fullpath.Length == 2)
            {
                //tooltip = GetTooltip(fullpath[0], fullpath[1]);
            }
            //else
            {
              //  tooltip = "fullpath length not 2";
            }
            string[] strPres = eventArgument.Split(new string[]{"!!!"},StringSplitOptions.None);
            if (strPres.Length == 2)
            {
                switch (strPres[0])
                {
                    case "A": tooltip = GetTooltip(strPres[1]); break;
                    case "B": RaiseCallbackEvent11(strPres[1]); break;
                    default: break;
                }
                
            }
        }

        public string GetCallbackResult()
        {
            return tooltip;
        }

        protected string GetTooltip(string str1)
        {
            //return the data from database, I simply add somes comments instead.
            //DataTable dtresult=SQL.GetTable(@"select * from annonces_r where poste='"+str1+"' and entreprise='"+str2+"'");
            string strreturn="";
            //if(dtresult != null)
            //{

            strreturn = str1+" : "+SQL.Get(@"select descriptionshort from annonces_r where id="+str1);
               // strreturn=dtresult.Rows[0]["id"]+" : "+dtresult.Rows[0]["descriptionshort"];
            //}
                return "this is just a demo: " +strreturn;
        }

        protected void TRow_Click(object sender, EventArgs e)
        {
            Response.Write("<script language='javascript'>alert('产品添加成功！')</script >");
        }

        public string StrDoc
        {
            get { return tooltip; }
        }
        public void RaiseCallbackEvent11(String eventArgument)
        {
            tooltip = "";
            string typeAnn = SQL.Get(@"select type_annonce from annonces_r where id=" + eventArgument);
            switch (typeAnn)
            {
                case "fullpage":
                    tooltip = "Annonce " + eventArgument;// + " : " + SQL.Get(@"select description from annonces_r where id=" + eventArgument);
                    //Server.Transfer("~/MemberPage/AnnoncePage.aspx", true);
                    //Response.Write("<script language='javascript'>window.open(\"http://www.asp.net\"')</script >");
                    break;
                case "lien":
                    tooltip = SQL.Get(@"select description from annonces_r where id=" + eventArgument);
                    
                    break;
                default: break;
            }
        }




        //part of tooltip example
        /*
        protected void Page_Load(object sender, EventArgs e)
        {
            String cbReference = Page.ClientScript.GetCallbackEventReference(this, "arg", "ReceiveServerData", "context");
            String callbackScript = "function CallTheServer() {" + cbReference + "; }";
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "CallTheServer", callbackScript, true);
        }
        */
    }


          
 




}